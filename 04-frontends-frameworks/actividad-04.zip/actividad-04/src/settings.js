const USER_KEY = 'userid';
const API = 'https://three-points.herokuapp.com/api/';

export {
  USER_KEY,
  API,
}